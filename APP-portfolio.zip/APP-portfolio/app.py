from flask import  Flask, render_template

app = Flask (__name__)

@app.route("/")
def home():
    nazev_webu =  "Petrovo Portfolio"
    titulek_webu = "Svět, který jsem si stvořili, je výsledkem našeho myšlení. Nelze jej změnit, pokud nejdříve nezměníme to, jak uvažujeme."
    popis = "Ukázka projektů, výuka s AI, a testování Jitsi2"
    technologie =  ["Flask", "Python", "HTML", "CSS", "Jitsi2", "Copilot"]

    return render_template("index.html", nazev_webu = nazev_webu, titulek_webu = titulek_webu)


if __name__ == "__main__":
    app.run(debug=True)